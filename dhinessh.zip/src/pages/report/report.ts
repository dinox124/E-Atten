import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from "@angular/http";



@IonicPage()
@Component({
  selector: 'page-report',
  templateUrl: 'report.html',
})
export class ReportPage {
  moviesList = [];
  totalArray = [];
  studentList;
  totalhour;
  Rn;
  Per;
  absentHour;
  valueList = [0];

  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http) {

    this.http.get("https://attendanceback.herokuapp.com/count").toPromise().then((filmList) => {
      // console.log(filmList.json());
      this.totalhour = filmList.json();
      this.moviesList = Array.of(filmList.json());
    }, (err) => {
      console.log(err);
    });
    
    this.http.get("https://collegekarur.herokuapp.com/atten").toPromise().then((filmList) => {
      // console.log(filmList.json());
      this.studentList = filmList.json();
      // console.log(this.studentList[1].id);

    }, (err) => {
      console.log(err);
    });
    this.con();
  }

  public updateItem() {
    for (let i = 0; i < this.studentList.length; i++) {

      // console.log(this.studentList[i].id);
      this.http.get(`https://attendanceback.herokuapp.com/getid/${this.studentList[i].id}`).toPromise().then((movie) => {
        // console.log(movie.json());
        this.studentList[i].value = movie.json();
        // console.log(this.studentList[i].value);
        this.Rn = (this.totalhour) - (movie.json());
        this.studentList[i].persentage = ((this.Rn / this.totalhour) * 100).toFixed(0);
        // console.log(this.studentList[i].persentage);
      });

    }
  }

  ionViewDidLoad() {

    console.log('ionViewDidLoad ReportPage');

  }

  con() {
    setTimeout(() => {
      this.updateItem();
    },
      1250);

  }



}
