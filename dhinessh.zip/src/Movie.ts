export class Movie{
    _id: number;
    title: string;
    isDone: boolean;
  }